# Jmeter_Grafana_Dashboards

This dashboard will provide you all the below jmeter metrics in real time:

1. Transactions Success Rate
2. Transactions Failure Rate
3. Total Transactions count
4. Total Passed Transactions
5. Total Failed Transactions
6. Running Vusers
7. Hits per second
8. Transactional Summary (Min, Max, Avg, 90th Percentile, Pass, Fail)
9. Pass Transactions Per Second
10. Fail Transactions Per Second
11. HTTP Status code Per Second
12. Transaction Response Time Trend

Let me know if any other metrics required, I will add that in new version of dashboard.
